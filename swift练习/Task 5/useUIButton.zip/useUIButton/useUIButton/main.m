//
//  main.m
//  useUIButton
//
//  Created by 张皓 on 4/21/16.
//  Copyright © 2016 张皓. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
